<span align="center">

##  Seja bem vindo(a)! 👋 

</span>

<p align="center">
  👩‍💻  Execucão: <strong>Para executar o mesmo baixar o Node: https://nodejs.org/en/download/
Após isso clonar o projeto: https://github.com/AlefaTeixeira/Teste_e2e_amazon.git
Próximo passo: executar o comando via terminal: npm install
Por fim, rodar o comando: npx cypress open, onde o mesmo criará algumas dependências e abrirá o navegador para execução.

Os testes Web e API estão no mesmo diretório: Cypress/e2e/Amazon -> para Web
                                             : </strong>
</p>


![Screenshot_1](https://user-images.githubusercontent.com/47541718/219797913-2bcd7350-fe4d-42f4-a55d-169fcd809c9a.png)
![Screenshot_2](https://user-images.githubusercontent.com/47541718/219798055-46e09a45-20cc-49c7-9e81-faeb60be4560.png)
![Screenshot_3](https://user-images.githubusercontent.com/47541718/219798253-ca0a7048-613c-42ff-9914-4d8c93802a9c.png)
![Screenshot_4](https://user-images.githubusercontent.com/47541718/219798296-f4e197e6-6e0a-42a3-bb00-ffd84464db7a.png)


<p align="center">
  💼 Escolha ferramenta: <strong>escolhi o Cypress para as automações devido a familiriade com o mesmo.</strong>
</p>
